Introduction

Metadata Driven Framework (MDF) is made to process the ingestion and processing of landed file in data lake into
different zones of data lake in delta lake format leveraging use of Spark engine for data movement and processing.
Metadata Driven Framework is being designed to be cost effective by relying on serverless azure objects such as Azure Functions
and Azure Synapse serverless.

The main core of the framework is based on metadata variables setup on arrival folder of files where business user can customize the loading of data to be Full Truncate or Full Upsert load. he also has option to decide whether to maintain SCD type 2 on dimensions and determine whether to apply partitioning to optimize the loading performance.

Getting Started

Check Metadata Driven Framework Wiki in below link

https://dev.azure.com/empired/Empired-Data-AI-Integration/_wiki/wikis/Empired-Integration-Practice.wiki/948/Metadata-Driven-Framework
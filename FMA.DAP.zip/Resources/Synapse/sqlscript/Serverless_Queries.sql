select getdate() as today_date;
--CREATE DATABASE [intergen-data-mdp-synapse-serverless-sql-dev2]

declare @sql nvarchar(max)=''

drop table if exists #Metadata
select * into #Metadata
from INFORMATION_SCHEMA.COLUMNS
where TABLE_NAME in ('FilteredAccount',
'FilteredContact',
'FilteredCustomerAddress',
'Filtereddsl_afalicenserecords',
'Filtereddsl_afalicensing',
'Filtereddsl_afamonitoring',
'Filtereddsl_afarenewal',
'Filtereddsl_afatermination',
'Filtereddsl_afavariation',
'Filtereddsl_filing',
'Filtereddsl_filingtype',
'Filtereddsl_licencetype',
'Filteredfma_answerlibrary',
'Filteredfma_applicationtype',
'Filteredfma_approvalrequest',
'Filteredfma_casesubject',
'Filteredfma_casetreatmentsoutcome',
'Filteredfma_countrylibrary',
'Filteredfma_financialserviceprovider',
'Filteredfma_licenceapplication',
'Filteredfma_licencerelationship',
'Filteredfma_licencerelationshiptype',
'Filteredfma_licencetypesofadvice',
'Filteredfma_offeredservice',
'Filteredfma_qanda',
'Filteredfma_questioncaptiondefinition',
'Filteredfma_questiongroup',
'Filteredfma_questiongrouptype',
'Filteredfma_questionslibrary',
'Filteredfma_regulatoryreportingperiod',
'FilteredIncident')


select  @sql = @sql+ 'create or alter view [clare].[dbo_'+  base.TABLE_NAME+']
as
select 
	BusinessKeyHash,'+
	stuff((select ',
		 '+ column_name
		 
		 from  #Metadata md where md.TABLE_NAME=base.TABLE_NAME order by ORDINAL_POSITION for xml path('')), 1, 1, '')
		 +',
		 RunID,
		 NonBusinessKeyHash,
		 convert(bit,RowIsCurrent) as RowIsCurrent,
		 convert(datetime2,RowValidFrom) as RowValidFrom,
		 convert(datetime2,RowValidTo) as RowValidTo
from 
		openrowset(
		       bulk ''https://aedevdaphzftcul8.dfs.core.windows.net/staging/Clare/dbo__'+base.TABLE_NAME+'/'',
			   format =''Delta''
	     ) with ( BusinessKeyHash varchar(8000),'
		 +  stuff((select ',
		 '+ column_name+' '+case when DATA_TYPE='nvarchar' then DATA_TYPE+'('+replace(convert(nvarchar(500),CHARACTER_MAXIMUM_LENGTH),'-1','max')+')' 
		                                            when DATA_TYPE='timestamp' then 'varbinary(8000)' 
													when DATA_TYPE='varbinary' and convert(nvarchar(500),CHARACTER_MAXIMUM_LENGTH)='-1' then 'varbinary(max)'  else  DATA_TYPE  end
		 
		 from  #Metadata md where md.TABLE_NAME=base.TABLE_NAME order by ORDINAL_POSITION for xml path('')), 1, 1, '')
		 +',
		 NonBusinessKeyHash varchar(8000),
		 RunID varchar(500),
		 RowIsCurrent varchar(8000),
		 RowValidFrom varchar(8000),
		 RowValidTo varchar(8000),
		 RawFilePath nvarchar(500)
		 
		 ) AS [result]
		 
		 Go
		 
		 '
		  
         
 
from 

(select distinct TABLE_NAME from

#Metadata ) base

--where TABLE_NAME='FilteredAccount'


select cast(convert(nvarchar(max), '<?Query --') + char(13) + replace(@sql,'&#x0D;','') + char(13) + '--?>' as xml) as 'DynamicSQL'


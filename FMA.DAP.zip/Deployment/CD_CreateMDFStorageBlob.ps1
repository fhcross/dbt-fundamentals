
#Write-Host "Running Deploy MDDF Storage Account script..."

if($env:StorageAccount_Enable -eq "True")
{
    $StorageAccount = Get-AzStorageAccount -ResourceGroupName $env:ResouceGroup_Name -Name $env:StorageAccount_Name -ErrorAction SilentlyContinue
    if ($null -eq $StorageAccount) 
    {
        Write-Host "Creating Storage Account..."
        New-AzResourceGroupDeployment `
        -ResourceGroupName $env:ResouceGroup_Name `
        -TemplateFile .\Deployment\arm\'01-Storage5.json' `
        -storageAccountName $env:StorageAccount_Name `
        -storageSKU $env:StorageAccount_SKU `
        -IsHierarchyEnabled $env:StorageAccount_HierarchyEnable
        #Write-Host "Reading Access Key of Storage Account..."
        #$AccessKey = Get-AzStorageAccountKey -ResourceGroupName $env:ResouceGroup_Name -storageAccountName $env:StorageAccount_Name
        #$secretvalue = ConvertTo-SecureString $AccessKey[0].Value -AsPlainText -Force
        #Write-Host "Adding Access Key of Storage Account as a secret to the Key Vault..."
        #Set-AzKeyVaultSecret -VaultName $env:KeyVault_Name -Name $env:KeyVault_StorageAccount_AccessKey -SecretValue $secretvalue
    }
    else
    {
        Write-Host "$env:StorageAccount_Name exists"

    }
    
}
Write-Host "Creating containers if not exists..."
#$AccessKey = Get-AzStorageAccountKey -ResourceGroupName $env:ResouceGroup_Name -storageAccountName $env:StorageAccount_Name
$storageAcc = Get-AzStorageAccount -StorageAccountName $env:StorageAccount_Name -ResourceGroupName $env:ResouceGroup_Name #-StorageAccountKey $AccessKey[0].Value
$ctx=$storageAcc.Context 
$landingexist = Get-AzStorageContainer -Context $ctx | Where-Object { $_.Name -eq $env:StorageAccount_LandingContainer }
if ($null -eq $landingexist)
{
    New-AzStorageContainer -Name $env:StorageAccount_LandingContainer -Context $ctx -Permission Container
}
$stagingexist = Get-AzStorageContainer -Context $ctx | Where-Object { $_.Name -eq $env:StorageAccount_StagingContainer }
if ($null -eq $stagingexist)
{   
    New-AzStorageContainer -Name $env:StorageAccount_StagingContainer -Context $ctx -Permission Container
}
$rawexist = Get-AzStorageContainer -Context $ctx | Where-Object { $_.Name -eq $env:StorageAccount_RawContainer }
if ($null -eq $rawexist)
{
    New-AzStorageContainer -Name $env:StorageAccount_RawContainer -Context $ctx -Permission Container
}
$curatedexist = Get-AzStorageContainer -Context $ctx | Where-Object { $_.Name -eq $env:StorageAccount_CuratedContainer }
if ($null -eq $curatedexist)
{
    New-AzStorageContainer -Name $env:StorageAccount_CuratedContainer -Context $ctx -Permission Container
}
$systemexist = Get-AzStorageContainer -Context $ctx | Where-Object { $_.Name -eq "system" }
if ($null -eq $systemexist)
{
    New-AzStorageContainer -Name "system" -Context $ctx  -Permission Container
}

Write-Host "Uploading necessary files to the system zone..."
    $filesystemName = "system"  
    $localSrcFile =  "Resources/ADLS/Functions/ConvertToDelta.py"
    $dirname = "Functions/"
    $destPath = $dirname + (Get-Item $localSrcFile).Name
    New-AzDataLakeGen2Item -Context $ctx -FileSystem $filesystemName -Path $destPath -Source $localSrcFile -Force

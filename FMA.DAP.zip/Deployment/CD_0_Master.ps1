
$a = pwsh --version
$b = get-command Invoke-Sqlcmd | Select Version
Write-Host "Powershell Version: $a" 
Write-Host "Invoke-Sqlcmd Version: $b"
Write-Host "SP_Client_ID: ${env:SP_CLIENT_ID}"
Write-Host "SP_Client_Secret: ${env:SP_CLIENT_SECRET}"
Write-Host "SP_Tenant_ID: ${env:SP_TENANT_ID}"
# Before running you must create service principal and add it as owner to the resource group
# Password of sqladminuser of synapse serverless DB must be more than 8 characters with numbers and alph and special character
# after synapse creation make sure SP is synapse administrator of synapse
# Make sure names of azure resources are uniques and  havent used before
#az login --service-principal -u ${env:SP_CLIENT_ID} -p ${env:SP_CLIENT_SECRET} --tenant ${env:SP_TENANT_ID}
$azurePassword = ConvertTo-SecureString ${env:SP_CLIENT_SECRET} -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ${env:SP_CLIENT_ID}, $azurePassword
Connect-AzAccount -ServicePrincipal -TenantId ${env:SP_TENANT_ID} -Credential $Credential
Invoke-Expression -Command  "Deployment/CD_CreateMDFResourceGroup.ps1"
Invoke-Expression -Command  "Deployment/CD_CreateMDFKeyVault.ps1"
Invoke-Expression -Command  "Deployment/CD_CreateMDFStorageBlob.ps1"
Invoke-Expression -Command  "Deployment/CD_CreateMDFFunctionApp.ps1"
Invoke-Expression -Command  "Deployment/CD_CreateMDFSynapseApp.ps1"
Invoke-Expression -Command  "Deployment/CD_ConfigureMDFFunctionApp.ps1"
#Invoke-Expression -Command  "Deployment/CD_ConfigureADLSMetadata.ps1"
Invoke-Expression -Command  "Deployment/CD_GrantRBAC.ps1"

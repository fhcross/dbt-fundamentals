
#Write-Host "Running Configure MDDF function app script..."
if($env:FunctionApp_ConfigureEnable -eq "True")
{
    Write-Host "Zipping the function codes then publishing"
    
    Compress-Archive -Path "Resources/function/*" -Update -DestinationPath "Resources/function/function29.zip"
    Publish-AzWebapp -ResourceGroupName $env:ResouceGroup_Name -Name $env:FunctionApp_Name -ArchivePath "Resources/function/function29.zip" -Force
    
}
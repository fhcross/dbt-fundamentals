param
(
    [parameter(Mandatory = $false)] [String] $armTemplate,
    [parameter(Mandatory = $false)] [String] $WorkspaceName,
    [parameter(Mandatory = $false)] [Bool] $predeployment = $true
)

function triggerSortUtil {
    param([Microsoft.Azure.Commands.Synapse.Models.PSTriggerResource]$trigger,
        [Hashtable] $triggerNameResourceDict,
        [Hashtable] $visited,
        [System.Collections.Stack] $sortedList)
    if ($visited[$trigger.Name] -eq $true) {
        return;
    }
    $visited[$trigger.Name] = $true;
    if ($trigger.Properties.DependsOn) {
        $trigger.Properties.DependsOn | Where-Object { $_ -and $_.ReferenceTrigger } | ForEach-Object {
            triggerSortUtil -trigger $triggerNameResourceDict[$_.ReferenceTrigger.ReferenceName] -triggerNameResourceDict $triggerNameResourceDict -visited $visited -sortedList $sortedList
        }
    }
    $sortedList.Push($trigger)
}

function Get-SortedTriggers {
    param([string] $WorkspaceName)
    $triggers = Get-AzSynapseTrigger -WorkspaceName $WorkspaceName
    $triggerDict = @{}
    $visited = @{}
    $stack = new-object System.Collections.Stack
    $triggers | ForEach-Object { $triggerDict[$_.Name] = $_ }
    $triggers | ForEach-Object { triggerSortUtil -trigger $_ -triggerNameResourceDict $triggerDict -visited $visited -sortedList $stack }
    $sortedList = new-object Collections.Generic.List[Microsoft.Azure.Commands.Synapse.Models.PSTriggerResource]
    
    while ($stack.Count -gt 0) {
        $sortedList.Add($stack.Pop())
    }
    $sortedList
}


$templateJson = Get-Content $armTemplate | ConvertFrom-Json
$resources = $templateJson.resources

#Triggers 
Write-Host "Getting triggers"
$triggersInTemplate = $resources | Where-Object { $_.type -eq "Microsoft.Synapse/workspaces/triggers" }
$triggerNamesInTemplate = $triggersInTemplate | ForEach-Object { $_.name.Substring(39, $_.name.Length - 42) }
Write-Host "TriggersInTemplate"
Write-Host $triggerNamesInTemplate

$triggersDeployed = Get-SortedTriggers -WorkspaceName $WorkspaceName
Write-Host "TriggersDeployed"
Write-Host $triggersDeployed

$triggersToStop = $triggersDeployed | Where-Object { $triggerNamesInTemplate -contains $_.Name } | ForEach-Object { 
    New-Object PSObject -Property @{
        Name        = $_.Name
        TriggerType = $_.Properties.GetType().Name 
    }
}

$triggersToStart = $triggersInTemplate | Where-Object { $_.properties.runtimeState -eq "Started" -and ($_.properties.pipelines.Count -gt 0 -or $_.properties.pipeline.pipelineReference -ne $null) } | ForEach-Object { 
    New-Object PSObject -Property @{
        Name        = $_.name.Substring(39, $_.name.Length - 42)
        TriggerType = $_.Properties.type
    }
}

if ($predeployment -eq $true) {
    #Stop all triggers
    Write-Host "Stopping deployed triggers"
    Write-Host $triggersToStop
    $triggersToStop | ForEach-Object {
        Write-Host "Process Trigger:" $_.Name $_.TriggerType

        if ($_.TriggerType -eq "BlobEventsTrigger" -or $_.TriggerType -eq "CustomEventsTrigger") {
            Write-Host "Unsubscribing" $_.Name "from events"
            $status = Remove-AzSynapseTriggerSubscription -WorkspaceName $WorkspaceName -Name $_.Name -Force -Confirm:$false
            while ($status.Status -ne "Disabled") {
                Start-Sleep -s 15
                $status = Get-AzSynapseTriggerSubscriptionStatus -WorkspaceName $WorkspaceName -Name $_.Name
            }
        }
        Write-Host "Stopping trigger" $_.Name
        Stop-AzSynapseTrigger -WorkspaceName $WorkspaceName -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue
    }
}
else {
    #Start active triggers
    Write-Host "Starting active triggers"
    Write-Host $triggersToStart
    $triggersToStart | ForEach-Object { 
        Write-Host "Process Trigger:" $_.Name $_.TriggerType

        if ($_.TriggerType -eq "BlobEventsTrigger" -or $_.TriggerType -eq "CustomEventsTrigger") {
            Write-Host "Subscribing" $_.Name "to events"
            $status = Add-AzSynapseTriggerSubscription -WorkspaceName $WorkspaceName -Name $_.Name -Confirm:$false
            while ($status.Status -ne "Enabled") {
                Start-Sleep -s 15
                $status = Get-AzSynapseTriggerSubscriptionStatus  -WorkspaceName $WorkspaceName -Name $_.Name
            }
        }
        Write-Host "Starting trigger" $_.Name
        Start-AzSynapseTrigger -WorkspaceName $WorkspaceName -Name $_.Name -Confirm:$false -ErrorAction SilentlyContinue
    }
}